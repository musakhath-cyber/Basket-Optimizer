
import re
import pandas as pd

CANONICAL_HEADERS = {
    "item": ["item", "product", "description", "product name", "item name", "sku name", "stock item"],
    "price": ["price", "unit price", "cost", "price (excl vat)", "price excl vat", "rate", "best price"],
    "uom": ["uom", "unit", "unit of measure", "pack size", "pack"],
    "category": ["category", "dept", "department", "product category"],
}

PERISHABLE_CATEGORIES = {
    "fresh veg", "fresh produce", "produce", "meat", "poultry", "dairy",
    "butchery", "seafood", "fish", "bakery", "fresh fruit & vegetables",
}
NON_PERISHABLE_CATEGORIES = {
    "dry goods", "chemicals", "cleaning", "packaging", "beverages", "grocery",
}

def _norm(x):
    return re.sub(r"\s+", " ", str(x).strip().lower())

def _resolve_headers(columns):
    normalized = {_norm(c): c for c in columns}
    resolved = {}
    for canon, aliases in CANONICAL_HEADERS.items():
        for alias in aliases:
            if _norm(alias) in normalized:
                resolved[canon] = normalized[_norm(alias)]
                break
    return resolved

def _find_header_row(raw, scan_rows=30):
    for i in range(min(scan_rows, len(raw))):
        vals = {_norm(v) for v in raw.iloc[i].tolist() if pd.notna(v)}
        has_item = bool(vals & set(CANONICAL_HEADERS["item"]))
        has_price = bool(vals & set(CANONICAL_HEADERS["price"]))
        if has_item and has_price:
            return i
    return None

def _infer_perishable(category):
    if not category or not isinstance(category, str):
        return True
    c = _norm(category)
    if c in NON_PERISHABLE_CATEGORIES:
        return False
    if c in PERISHABLE_CATEGORIES:
        return True
    return True

_PACK_SIZE_RE = re.compile(r"(\d+(?:\.\d+)?)\s*(kg|g|l|ml|ea|each|unit|units)", re.I)

def normalize_unit_price(raw_price, uom_text):
    if not uom_text or not isinstance(uom_text, str):
        return raw_price, "ea"
    m = _PACK_SIZE_RE.search(uom_text)
    if not m:
        return raw_price, "ea"
    size = float(m.group(1))
    unit_raw = m.group(2).lower()
    unit = {"g":"kg","ml":"l","each":"ea","units":"ea","unit":"ea"}.get(unit_raw, unit_raw)
    if size <= 0:
        return raw_price, unit
    if unit_raw == "g":
        size /= 1000
    elif unit_raw == "ml":
        size /= 1000
    return round(raw_price / size, 4), unit

def load_catalog_from_table(df, normalize_uom=True):
    headers = _resolve_headers(df.columns)
    if "item" not in headers or "price" not in headers:
        raise ValueError(
            f"Could not find item/price columns. Found columns: {list(df.columns)}. "
            f"Resolved: {headers}."
        )
    catalog = {}
    for _, row in df.iterrows():
        item = row.get(headers["item"])
        raw = row.get(headers["price"])
        if pd.isna(item) or pd.isna(raw):
            continue
        try:
            price = float(str(raw).replace("R","").replace(",","").strip())
        except Exception:
            continue
        if price <= 0:
            continue
        uom = row.get(headers["uom"]) if "uom" in headers else None
        category = row.get(headers["category"]) if "category" in headers else "Uncategorized"
        unit_price, base_unit = normalize_unit_price(price, str(uom)) if normalize_uom and pd.notna(uom) else (price, "ea")
        display = f"{str(item).strip()} ({base_unit})" if base_unit else str(item).strip()
        catalog[display] = {
            "price": unit_price,
            "category": category if isinstance(category, str) else "Uncategorized",
            "perishable": _infer_perishable(category),
        }
    return catalog

def load_catalog_from_excel(path, sheet_name=0):
    raw = pd.read_excel(path, sheet_name=sheet_name, header=None)
    header_row = _find_header_row(raw)
    if header_row is None:
        raise ValueError(f"No product header row found on sheet '{sheet_name}'.")
    df = pd.read_excel(path, sheet_name=sheet_name, header=header_row)
    return load_catalog_from_table(df)

def load_buying_manual(path):
    """
    Parses the January 2026-style workbook:
    - ignores COVER/non-product sheets
    - finds headers even when they are not on row 1
    - recognizes Stock Item and BEST PRICE
    - returns a catalog plus detected supplier columns for each sheet
    """
    xls = pd.ExcelFile(path)
    sheets = []
    for sheet in xls.sheet_names:
        raw = pd.read_excel(path, sheet_name=sheet, header=None)
        header_row = _find_header_row(raw)
        if header_row is None:
            continue
        df = pd.read_excel(path, sheet_name=sheet, header=header_row)
        resolved = _resolve_headers(df.columns)
        if "item" not in resolved:
            continue
        # Build a single best-price catalog for this sheet.
        try:
            catalog = load_catalog_from_table(df)
        except ValueError:
            continue
        supplier_cols = []
        reserved = set(resolved.values()) | {"Category", "Stock Item", "UOM", "NEW CODE", "BEST PRICE", "PREFERRED SUPPLIER"}
        for col in df.columns:
            if pd.isna(col):
                continue
            name = str(col).strip()
            if name and name.upper() not in {str(x).upper() for x in reserved} and not name.lower().startswith("unnamed"):
                supplier_cols.append(name)
        sheets.append({
            "sheet": sheet,
            "catalog": catalog,
            "supplier_columns": supplier_cols,
            "data": df,
        })
    if not sheets:
        raise ValueError("No product sheets with Stock Item/Product and Best Price/Price columns were found.")
    return sheets

def load_catalog_from_csv(path):
    raw = pd.read_csv(path, header=None)
    header_row = _find_header_row(raw)
    if header_row is None:
        raise ValueError("No item/price header row found.")
    df = pd.read_csv(path, header=header_row)
    return load_catalog_from_table(df)

def load_catalog_from_pdf(path, page_numbers=None):
    import pdfplumber
    frames = []
    with pdfplumber.open(path) as pdf:
        pages = pdf.pages if page_numbers is None else [pdf.pages[i] for i in page_numbers]
        for page in pages:
            for table in page.extract_tables():
                if table and len(table) >= 2:
                    header, *rows = table
                    frames.append(pd.DataFrame(rows, columns=header))
    if not frames:
        raise ValueError("No tables detected in PDF.")
    return load_catalog_from_table(pd.concat(frames, ignore_index=True))
