
import tempfile
from pathlib import Path
import pandas as pd
import streamlit as st
from ingest import load_buying_manual, load_catalog_from_excel, load_catalog_from_csv, load_catalog_from_pdf
from milp_solver import build_and_solve

st.set_page_config(page_title="Basket Optimizer", page_icon="🧾", layout="wide")
st.title("🧾 Basket Optimizer")
st.caption("Supplier buying-manual optimization — mobile friendly.")

if "suppliers" not in st.session_state: st.session_state.suppliers = {}
if "demand" not in st.session_state: st.session_state.demand = {}
if "optimization" not in st.session_state: st.session_state.optimization = None

st.sidebar.header("Add supplier")

with st.sidebar.form("supplier_form"):
    name = st.text_input("Supplier name", placeholder="e.g. Bell Ceres")
    moq = st.number_input("Minimum order value (R)", min_value=0.0, value=500.0, step=50.0)
    free = st.number_input("Free-delivery threshold (R)", min_value=0.0, value=500.0, step=50.0)
    delivery = st.number_input("Delivery fee (R)", min_value=0.0, value=100.0, step=10.0)
    uploaded = st.file_uploader("Buying manual", type=["xlsx","xls","csv","pdf"])
    add = st.form_submit_button("Add supplier", type="primary")

if add:
    if not name.strip():
        st.sidebar.error("Enter a supplier name.")
    elif uploaded is None:
        st.sidebar.error("Choose a buying manual.")
    else:
        tmp = tempfile.NamedTemporaryFile(delete=False, suffix=Path(uploaded.name).suffix.lower())
        tmp.write(uploaded.getvalue()); tmp.close()
        try:
            if Path(uploaded.name).suffix.lower() in [".xlsx",".xls"]:
                sheets = load_buying_manual(tmp.name)
                st.session_state["pending_manual"] = sheets
                st.sidebar.success(f"Manual read successfully: {len(sheets)} product sheets found.")
                st.session_state["pending_supplier"] = {"name":name, "moq":moq, "free":free, "delivery":delivery}
            elif Path(uploaded.name).suffix.lower() == ".csv":
                catalog = load_catalog_from_csv(tmp.name)
                st.session_state.suppliers[name] = {"moq":moq,"free_delivery_threshold":free,"delivery_fee":delivery,"catalog":catalog}
                st.sidebar.success(f"Added {name}: {len(catalog)} products.")
            else:
                catalog = load_catalog_from_pdf(tmp.name)
                st.session_state.suppliers[name] = {"moq":moq,"free_delivery_threshold":free,"delivery_fee":delivery,"catalog":catalog}
                st.sidebar.success(f"Added {name}: {len(catalog)} products.")
        except Exception as e:
            st.sidebar.error(f"Could not read the buying manual: {e}")
        finally:
            Path(tmp.name).unlink(missing_ok=True)

if st.session_state.get("pending_manual"):
    st.sidebar.subheader("Choose product sheet")
    sheets = st.session_state["pending_manual"]
    labels = [x["sheet"] for x in sheets]
    chosen = st.sidebar.selectbox("Sheet", labels)
    if st.sidebar.button("Use this sheet"):
        entry = next(x for x in sheets if x["sheet"] == chosen)
        p = st.session_state["pending_supplier"]
        st.session_state.suppliers[p["name"]] = {
            "moq":p["moq"], "free_delivery_threshold":p["free"],
            "delivery_fee":p["delivery"], "catalog":entry["catalog"]
        }
        st.session_state.pop("pending_manual", None)
        st.session_state.pop("pending_supplier", None)
        st.sidebar.success(f"Added {p['name']} from '{chosen}' — {len(entry['catalog'])} products.")
        st.rerun()

if st.session_state.suppliers:
    st.sidebar.subheader("Suppliers")
    for n in list(st.session_state.suppliers):
        st.sidebar.write(f"• {n} ({len(st.session_state.suppliers[n]['catalog'])} items)")
        if st.sidebar.button(f"Remove {n}", key=f"rm_{n}"):
            del st.session_state.suppliers[n]; st.rerun()

items = sorted({i for s in st.session_state.suppliers.values() for i in s["catalog"]})
t1,t2,t3=st.tabs(["📦 Demand","⚙️ Optimize","📊 Results"])

with t1:
    st.subheader("Required demand")
    if not items: st.info("Add a supplier and buying manual in the sidebar.")
    else:
        df=pd.DataFrame([{"Item":i,"Required quantity":st.session_state.demand.get(i,0.0)} for i in items])
        edited=st.data_editor(df,hide_index=True,use_container_width=True,disabled=["Item"],
                              column_config={"Required quantity":st.column_config.NumberColumn(min_value=0.0,step=1.0)})
        if st.button("Save demand",type="primary"):
            st.session_state.demand={r["Item"]:float(r["Required quantity"]) for _,r in edited.iterrows() if float(r["Required quantity"])>0}
            st.success("Demand saved.")

with t2:
    st.subheader("Optimization")
    admin=st.number_input("Admin PO fee (R)",min_value=0.0,value=100.0,step=10.0)
    if st.button("🚀 Optimize purchasing basket",type="primary",use_container_width=True):
        if not st.session_state.suppliers or not st.session_state.demand:
            st.error("Add suppliers and save demand first.")
        else:
            try:
                missing=[i for i in st.session_state.demand if not any(i in s["catalog"] for s in st.session_state.suppliers.values())]
                if missing:
                    st.error("Missing from all suppliers: "+", ".join(missing))
                else:
                    out=build_and_solve(st.session_state.suppliers,st.session_state.demand,admin_po_fee=admin)
                    st.session_state.optimization=out
                    if out[0].success: st.success(f"Optimal landed cost: R{out[0].fun:,.2f}")
                    else: st.error(out[0].message)
            except Exception as e: st.exception(e)

with t3:
    st.subheader("Results")
    o=st.session_state.optimization
    if not o: st.info("Run the optimizer first.")
    elif not o[0].success: st.error(o[0].message)
    else:
        result,pairs,pair_index,supplier_names,y_offset,z_offset,buffer_items=o
        st.metric("Optimal landed cost",f"R{result.fun:,.2f}")
        rows=[]
        for (item,sup),idx in pair_index.items():
            if result.x[idx]>1e-6:
                price=float(st.session_state.suppliers[sup]["catalog"][item]["price"]); qty=float(result.x[idx])
                rows.append({"Supplier":sup,"Item":item,"Type":"Buffer" if item in buffer_items else "Required","Quantity":qty,"Unit price":price,"Subtotal":qty*price})
        if rows:
            df=pd.DataFrame(rows); st.dataframe(df,hide_index=True,use_container_width=True)
            st.download_button("⬇️ Download purchase basket CSV",df.to_csv(index=False).encode(),"optimized_purchase_basket.csv","text/csv")
